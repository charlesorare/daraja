<?php

namespace Illuminate\Contracts\Events;

interface ShouldHandleEventsAfterCommit
{
    //
}
