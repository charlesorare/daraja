<?php

namespace Illuminate\Contracts\Auth\Middleware;

interface AuthenticatesRequests
{
    //
}
