<?php

namespace Illuminate\Routing;

/**
 * @deprecated
 */
trait RouteDependencyResolverTrait
{
    use ResolvesRouteDependencies;
}
