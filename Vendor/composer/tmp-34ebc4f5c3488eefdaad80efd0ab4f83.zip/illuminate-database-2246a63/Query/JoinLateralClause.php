<?php

namespace Illuminate\Database\Query;

class JoinLateralClause extends JoinClause
{
    //
}
